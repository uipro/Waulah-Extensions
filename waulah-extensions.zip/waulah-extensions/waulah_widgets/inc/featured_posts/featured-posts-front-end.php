<?php
	
	echo $before_widget;
	if ( !empty( $featured_title ) ) {
		echo $before_title . $featured_title . $after_title;
	}
?>

<?php
	switch ( $filter_posts_by ) {
		
		case "_post_like_count":			
		$args = array(
		  'post_type' => array( 'post' ),
		  'meta_key' => '_post_like_count',
		  'orderby' => 'meta_value_num',
		  'order' => 'DESC',
		  'posts_per_page' => $featured_posts_count,
		  'ignore_sticky_posts' => 1
		);		
		break;
		
		case "comment_count":			
		$args = array(
		  'post_type' => array( 'post' ),
		  'orderby' => 'comment_count',
		  'order' => 'DESC',
		  'posts_per_page' => $featured_posts_count,
		  'ignore_sticky_posts' => 1
		);	
		break;
		
		case "inf_featured_post":			
		$args = array(
		  'post_type' => array( 'post' ),
		  'meta_key' => 'inf_featured_post',
		  'orderby' => 'meta_value_num',
		  'order' => 'DESC',
		  'posts_per_page' => $featured_posts_count,
		  'ignore_sticky_posts' => 1
		);	
		break;
		
		default:
		$args = array(
		  'post_type' => array( 'post' ),
		  'posts_per_page' => $featured_posts_count,
		  'ignore_sticky_posts' => 1
		);
	}
	$wp_query = new WP_Query( $args );
?>
<?php if( $wp_query->have_posts() ) : while( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
<?php
	global $post; $post_thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'waulah-thumb' );
	$thumb_url = $post_thumb[0];
	$post_format = get_post_format();
?>
<div class="aside-article clearfix">
	<a class="thumb" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php if ( $post_format == 'video' ) : ?>	
		<?php
			$video_source = get_field( 'choose_video_source' );
			if( $video_source == 'youtube' ) {
				$video_id = get_field( 'youtube_video_id' );
				$video_thumb = "http://i1.ytimg.com/vi/$video_id/1.jpg";
				echo '<img src="' . $video_thumb . '" alt="' . get_the_title() . '">';
			} elseif ( $video_source == 'vimeo' ) {
				$video_id = get_field( 'vimeo_video_id' );
				$video_thumb =  unserialize(wp_remote_fopen("http://vimeo.com/api/v2/video/$video_id.php"));
				echo '<img src="' . $video_thumb[0]['thumbnail_small']. '" alt="' .get_the_title() . '">';
			}
		?>
		<?php elseif ( $thumb_url ) : ?><img src="<?php echo $thumb_url; ?>" alt="<?php the_title(); ?>">
		<?php else : ?><img src="http://placehold.it/320x230" alt="<?php the_title(); ?>"><?php endif; ?>
		<?php if ( $post_format == 'video' ): ?><i class="fa fa-play"></i><?php endif; ?>
		<?php if ( $post_format == 'quote' ): ?><i class="fa fa-quote-left"></i><?php endif; ?>
		<?php if ( $post_format == 'link' ): ?><i class="fa fa-link"></i><?php endif; ?>
		<?php if ( $post_format == 'image' || $post_format == 'gallery' ): ?><i class="fa fa-camera"></i><?php endif; ?>
	</a>
	<h4><a class="title" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
	<small><?php the_time( 'F j, Y' ); ?></small>
</div>
<?php endwhile; endif; wp_reset_postdata(); ?>
	
<?php echo $after_widget; ?>


