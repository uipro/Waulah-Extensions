<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('about_title'); ?>" type="text" value="<?php echo $about_title; ?>">
</p>
<p>
	<label>Image URL</label>
	<input class="widefat" name="<?php echo $this->get_field_name('about_img_url'); ?>" type="text" value="<?php echo $about_img_url; ?>">
</p>
<p>
	<label>About Yourself</label>
	<textarea class="widefat" rows="5" name="<?php echo $this->get_field_name('about_intro'); ?>"><?php echo $about_intro; ?></textarea>
</p>
<p>
	<label>Signature URL (optional)</label>
	<input class="widefat" name="<?php echo $this->get_field_name('about_signature'); ?>" type="text" value="<?php echo $about_signature; ?>">
</p>
<p>
	<label>Profile URL (optional)</label>
	<input class="widefat" name="<?php echo $this->get_field_name('about_profile'); ?>" type="text" value="<?php echo $about_profile; ?>">
</p>