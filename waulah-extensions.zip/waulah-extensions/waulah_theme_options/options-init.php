<?php

    /**
     * For full documentation, please visit: http://docs.reduxframework.com/
     * For a more extensive sample-config file, you may look at:
     * https://github.com/reduxframework/redux-framework/blob/master/sample/sample-config.php
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "waulah_options";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name' => 'waulah_options',
        'display_name' => 'Waulah Theme Options',
        'display_version' => '1.0.0',
        'page_slug' => 'waulah_options',
        'page_title' => 'Theme Options',
        'update_notice' => TRUE,
        'admin_bar' => TRUE,
        'menu_type' => 'menu',
        'menu_title' => 'Theme Options',
        'menu_icon' => 'dashicons-art',
        'allow_sub_menu' => TRUE,
        'page_parent_post_type' => 'your_post_type',
        'page_priority' => '25',
        'customizer' => TRUE,
        'default_show' => TRUE,
        'default_mark' => '*',
        'class' => 'waulah-options',
        'hints' => array(
            'icon' => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color' => '#66abe8',
            'icon_size' => 'normal',
            'tip_style' => array(
                'color' => 'dark',
                'style' => 'bootstrap',
            ),
            'tip_position' => array(
                'my' => 'top center',
                'at' => 'top left',
            ),
            'tip_effect' => array(
                'show' => array(
                    'effect' => 'slide',
                    'duration' => '500',
                    'event' => 'mouseover',
                ),
                'hide' => array(
                    'effect' => 'slide',
                    'duration' => '500',
                    'event' => 'mouseleave unfocus',
                ),
            ),
        ),
        'output' => TRUE,
        'output_tag' => TRUE,
        'settings_api' => TRUE,
        'cdn_check_time' => '1440',
        'compiler' => TRUE,
        'page_permissions' => 'manage_options',
        'save_defaults' => TRUE,
        'show_import_export' => TRUE,
        'database' => 'options',
        'transient_time' => '3600',
        'network_sites' => TRUE,
		'disable_tracking' => TRUE,
		'dev_mode' => FALSE
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'waulah-extensions' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'waulah-extensions' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'waulah-extensions' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'waulah-extensions' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>', 'waulah-extensions' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */
		
	// general settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'General Settings', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Adjust options the affect the entire theme.', 'waulah-extensions' ),
        'id'         => 'general-settings',
        'icon'   => 'el el-cog',
		'fields'     => array(
			 array(
                'id'       => 'show-likes',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Likes', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Select whether to show or hide post likes.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'On',
                'off'      => 'Off',
            ),
			array(
                'id'       => 'show-views',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Views', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Select whether to show or hide post views count.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'On',
                'off'      => 'Off',
            ),
			array(
				'id'       => 'sidebar-position',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar Position', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered sidebar position in single post.', 'waulah-extensions' ),
				'options'  => array(
					'sidebar-left' => 'Sidebar Left',
					'sidebar-right' => 'Sidebar Right',
				),
				'default'  => 'sidebar-right',
			),
             array(
				'id'       => 'page-layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Page Layout', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'You can choose between \'fullwidth\' or \'boxed\' layout.', 'waulah-extensions' ),
				'options'  => array(
					'fullwidth' => 'Fullwidth',
					'boxed' => 'Boxed',
				),
				'default'  => 'fullwidth',
			)
		)
     ));
	 
	 
	// header settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header', 'waulah-extensions' ),
        'desc'       => esc_html__( 'All header related settings.', 'waulah-extensions' ),
        'id'         => 'page-header',
        'icon'   => 'el el-bell',
		'fields'     => array(
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Logo', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Upload logo here.', 'waulah-extensions' ),
        'id'         => 'page-logo',
        'subsection' => true,
		'fields'     => array(
             array(
                'id'       => 'waulah-logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Header Logo', 'waulah-extensions' ),
				'desc'     => esc_html__( 'Recomended logo size is 440x120 pixels.', 'waulah-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your logo in JPG, PNG or GIF format.', 'waulah-extensions' )
            ),
			array(
                'id'       => 'waulah-logo-alt',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Alternate Logo', 'waulah-extensions' ),
				'desc'     => esc_html__( 'You can upload alternate light version of your logo. This logo will be used on dark navigation.', 'waulah-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your logo in JPG, PNG or GIF format.', 'waulah-extensions' )
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Top Nav Bar', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Options to show/hide top navigation bar elements.', 'waulah-extensions' ),
        'id'         => 'page-top-nav',
        'subsection' => true,
		'fields'     => array(
			array(
                'id'       => 'top-nav-show',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Entire Top Nav Bar ', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can enable or disable entire top nav bar section from here.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
				'id'       => 'top-nav-color',
				'required' => array( 'top-nav-show', '=', '1' ),
				'type'     => 'select',
				'title'    => esc_html__( 'Top Navbar Color Scheme', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'You can choose between \'light\' or \'dark\' color scheme.', 'waulah-extensions' ),
				'options'  => array(
					'light-scheme' => 'Light Color Scheme',
					'dark-scheme' => 'Dark Color Scheme',
				),
				'default'  => 'light-scheme',
			),
			array(
                'id'       => 'top-nav-bg-color',
                'type'     => 'color',
				'required' => array( 'top-nav-show', '=', '1' ),
                'title'    => esc_html__( 'Top Navbar Background Color', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Choose your preferred custom background color for top navbar.', 'waulah-extensions' ),
				'desc' => esc_html__( 'Note: You can change text color by changing the \'Top Navbar Color Scheme\' option.', 'waulah-extensions' ),
                'default'  => '#242526',
            ),
			array(
				'id'       => 'top-nav-use',
				'required' => array( 'top-nav-show', '=', '1' ),
				'type'     => 'select',
				'title'    => esc_html__( 'Use top nav as a \'menu bar\' or a \'notification bar\'', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'You can use this bar to show custom notification or top menu & date.', 'waulah-extensions' ),
				'options'  => array(
					'1' => 'Top Menu & Date',
					'0' => 'Notification Bar',
				),
				'default'  => '1',
			),
			array(
                'id'       => 'waulah-date-tme',
                'type'     => 'switch',
				'required' => array( 'top-nav-use', '=', '1' ),
                'title'    => esc_html__( 'Show or Hide Current Date', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide current date display in top nav bar here.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'waulah-top-nav',
                'type'     => 'switch',
				'required' => array( 'top-nav-use', '=', '1' ),
                'title'    => esc_html__( 'Show or Hide Nav Menu', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide nav menu in top nav bar here.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
				'id'       => 'top-menu-alignment',
				'required' => array( 'waulah-top-nav', '=', '1' ),
				'type'     => 'select',
				'title'    => esc_html__( 'Menu Alignment', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Select menu alignment \'left\' or \'right\'.', 'waulah-extensions' ),
				'options'  => array(
					'right-align' => 'Right Align',
					'left-align' => 'Left Align',
				),
				'default'  => 'right',
			),
			array(
                'id'       => 'notification-text',
                'type'     => 'text',
				'required' => array( 'top-nav-use', '=', '0' ),
                'title'    => esc_html__( 'Notification Text', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your message here.', 'waulah-extensions' ),
                'desc' => esc_html__( 'Allowed HTML tags are \'em\' and \'strong\'.', 'waulah-extensions' ),
            ),
			array(
                'id'       => 'notification-url',
                'type'     => 'text',
				'required' => array( 'top-nav-use', '=', '0' ),
                'title'    => esc_html__( 'Notification target url', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter target url here, if you want to make notification bar clickable.', 'waulah-extensions' ),
                'validate' => 'url',
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Main Menu', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Options to change main menu color scheme and dropdown menu color scheme.', 'waulah-extensions' ),
        'id'         => 'page-main-menu',
        'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'nav-color-scheme',
				'type'     => 'select',
				'title'    => esc_html__( 'Main Menu Color Scheme', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose between light and dark layout.', 'waulah-extensions' ),
				'options'  => array(
					'navbar-default' => 'Light',
					'navbar-inverse' => 'Dark',
				),
				'default'  => 'navbar-default',
			),
			array(
				'id'       => 'main-menu-color',
				'type'     => 'color',
				'title'    => esc_html__( 'Main Menu Background Color', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Here you can set an optional custom background color for main menu.', 'waulah-extensions' ),
				'desc' => esc_html__( 'Note: You can change text color by changing the \'Main Menu Color Scheme\' option.', 'waulah-extensions' ),
                'default'  => '',
			)
		)
     ));
	// header settings END
	
	
	// footer settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer', 'waulah-extensions' ),
        'desc'       => esc_html__( 'All footer related settings can be done from here.', 'waulah-extensions' ),
        'id'         => 'page-footer',
        'icon'   => 'el el-flag',
		'fields'     => array(
			 array(
				'id'       => 'footer-color',
				'type'     => 'select',
				'title'    => esc_html__( 'Footer Color Scheme', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered color scheme for footer.', 'waulah-extensions' ),
				'options'  => array(
					'dark-layout' => 'Dark Color Scheme',
					'light-layout' => 'Light Color Scheme',
				),
				'default'  => 'dark-layout',
			),
			array(
                'id'       => 'waulah-footer',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Widgets', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Select to show or hide footer widgets here.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
			array(
                'id'       => 'footer-nav',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Navigation', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Select to show or hide footer navigation.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
			array(
                'id'       => 'waulah-copyright',
                'type'     => 'text',
                'title'    => esc_html__( 'Copyright Text', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your custom copyright text here.', 'waulah-extensions' ),
                'desc'     => esc_html__( 'No need to include © character.', 'waulah-extensions' )
            )
		)
    ) );	
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Newsletter', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Show or hide bottom newsletter widget.', 'waulah-extensions' ),
        'id'         => 'newsletter-section',
        'subsection' => true,
		'fields'     => array(
            array(
                'id'       => 'btm-newsletter',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show Newsletter Form', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Footer newsletter subscription form widget.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
			array(
                'id'       => 'mailchimp-action-url',
                'type'     => 'text',
				'validate' => 'url',
				'required' => array( 'btm-newsletter', '=', '1' ),
                'title'    => esc_html__( 'Mailchimp Form Action URL', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your mailchimp form action url here.', 'waulah-extensions' ),
                'desc'     => '<a href="http://kb.mailchimp.com/lists/signup-forms/host-your-own-signup-forms" title="' . esc_html__( 'How to get mailchimp form action url', 'waulah-extensions' ) . '" target="_blank">' . esc_html__( 'How to get mailchimp form action url?', 'waulah-extensions' ) . '</a>'
            )
		)
     ));
	// footer settings END
	
	// homepage settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Home Page', 'waulah-extensions' ),
        'desc'       => esc_html__( 'All homepage related settings.', 'waulah-extensions' ),
        'id'         => 'home-page',
        'icon'   => 'el el-website',
		'fields'     => array(
             array(
				'id'       => 'homepage-layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Home Page Layout', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered homepage layout.', 'waulah-extensions' ),
				'options'  => array(
					'content-sidebar' => 'Content With Sidebar',
					'no-sidebar' => 'No Sidebar',
				),
				'default'  => 'no-sidebar',
			),
			array(
				'id'       => 'pagination-type',
				'type'     => 'select',
				'title'    => esc_html__( 'Pagination Type', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered pagination type.', 'waulah-extensions' ),
				'options'  => array(
					'paginated-grid' => 'Paginated Links',
					'load-more-grid' => 'Load More Button',
					'infinite-grid' => 'Infinite Scroll',
				),
				'default'  => 'load-more-grid',
			)
		)
     ));
	 // featured slider
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Featured Slider', 'waulah-extensions' ),
        'desc'       => esc_html__( 'You can adjust slider related settings here.', 'waulah-extensions' ),
        'id'         => 'featured-slider',
        'subsection' => true,
        'icon'   => 'el el-screen',
		'fields'     => array(
			array(
                'id'       => 'show-slider',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Home Featured Slider', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can enable or disable homepage featured posts slider section here.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'slider-post-count',
                'type'     => 'text',
				'required' => array( 'show-slider', '=', '1' ),
                'title'    => esc_html__( 'Posts Count', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'How many posts you would like to display in homepage slider?', 'waulah-extensions' ),
				 'desc'     => esc_html__( 'Default value is 5', 'waulah-extensions' ),
                'validate' => 'numeric',
				'default'  => '5',
            ),
             array(
				'id'       => 'featured-post-option',
				'type'     => 'select',
				'required' => array( 'show-slider', '=', '1' ),
				'title'    => esc_html__( 'Display Posts By', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose an option, how posts will be displayed, in homepage grid.', 'waulah-extensions' ),
				'options'  => array(
					'recentely_published' => 'Recentely Published',
					'_post_like_count' => 'Most Liked',
					'comment_count' => 'Most Commented',
					'inf_featured_post' => 'Featured Posts',
				),
				'default'  => 'recentely_published',
			)
		)
     ));
	
	// blog settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog', 'waulah-extensions' ),
        'desc'       => esc_html__( 'Blog and single post settings.', 'waulah-extensions' ),
        'id'         => 'waulah-blog',
        'icon'   => 'el el-comment-alt',
		'fields'     => array(
			array(
                'id'       => 'readmore-option',
                'type'     => 'switch',
                'title'    => esc_html__( 'Continue Reading Button', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Select to show or hide continue reading button.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
			array(
                'id'       => 'sharing-options',
                'type'     => 'switch',
                'title'    => esc_html__( 'Social Sharing Buttons', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can choose here, whether to show or hide sharing options in single posts.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
             array(
				'id'       => 'sharing-options-placement',
				'type'     => 'select',
				'required' => array( 'sharing-options', '=', '1' ),
				'title'    => esc_html__( 'Sharing Buttons Placement', 'waulah-extensions' ),
				'subtitle' => esc_html__( 'Choose whether to show social button before post content, after post content or both before and after content.', 'waulah-extensions' ),
				'options'  => array(
					'before' => 'Before Content',
					'after' => 'After Content',
				),
				'default'  => 'before',
			),
			 array(
                'id'       => 'show-author-box',
                'type'     => 'switch',
                'title'    => esc_html__( 'Author Info Box', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can choose to show or hide author box, after post content, on each single post.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
			array(
                'id'       => 'prev-next-article',
                'type'     => 'switch',
                'title'    => esc_html__( 'Previous/Next Article', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Show or Hide previous & next article links after post content in single post.', 'waulah-extensions' ),
                'default'  => 1,
                'on'       => 'Show',
                'off'      => 'Hide',
            )
		)
     ));
	// blog settings END
	
	// social links START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Links', 'waulah-extensions' ),
        'desc'       => esc_html__( 'All social network links should be added from here.', 'waulah-extensions' ),
        'id'         => 'social',
        'icon'   => 'dashicons dashicons-share',
		'fields'     => array(
			array(
                'id'       => 'facebook',
                'type'     => 'text',
                'title'    => esc_html__( 'Facebook', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your facebook profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'twitter',
                'type'     => 'text',
                'title'    => esc_html__( 'Twitter', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your twitter profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'linkedin',
                'type'     => 'text',
                'title'    => esc_html__( 'Linkedin', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your linkedin profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'pinterest',
                'type'     => 'text',
                'title'    => esc_html__( 'Pinterest', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your pinterest profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'google-plus',
                'type'     => 'text',
                'title'    => esc_html__( 'Google Plus', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your google+ profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'youtube',
                'type'     => 'text',
                'title'    => esc_html__( 'Youtube', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your youtube profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'tumblr',
                'type'     => 'text',
                'title'    => esc_html__( 'Tumblr', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your tumblr profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'instagram',
                'type'     => 'text',
                'title'    => esc_html__( 'Instagram', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your instagram profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'reddit',
                'type'     => 'text',
                'title'    => esc_html__( 'Reddit', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your reddit profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'flickr',
                'type'     => 'text',
                'title'    => esc_html__( 'Flickr', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your flickr profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'dribbble',
                'type'     => 'text',
                'title'    => esc_html__( 'Dribbble', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your dribbble profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'vimeo',
                'type'     => 'text',
                'title'    => esc_html__( 'Vimeo', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your vimeo profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'soundcloud',
                'type'     => 'text',
                'title'    => esc_html__( 'Soundcloud', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your soundcloud profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'vk',
                'type'     => 'text',
                'title'    => esc_html__( 'vk', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your vk profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'behance',
                'type'     => 'text',
                'title'    => esc_html__( 'Behance', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your behance profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'github',
                'type'     => 'text',
                'title'    => esc_html__( 'GitHub', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Enter your github profile link here.', 'waulah-extensions' ),
                'validate' => 'url',
            )
		)
    ) );
	// social links END
	
	
	// theme color options START
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Accent Color', 'waulah-extensions' ),
        'id'         => 'waulah-theme-colors',
        'desc'       => esc_html__( 'You can select your preferred theme accent color here.', 'waulah-extensions' ),
        'icon'  => 'el el-brush',
        'fields'     => array(
            array(
                'id'       => 'waulah-accent-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Accent Color', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Choose your preferred custom theme accent color.', 'waulah-extensions' ),
                'default'  => '#f83030',
            )
        ),
    ) );
	
	
	// theme typography settings
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Typography', 'waulah-extensions' ),
        'id'     => 'typography',
        'desc'   => esc_html__( 'Typography options allows you to enable and choose custom google fonts for your website.', 'waulah-extensions' ),
        'icon'   => 'el el-font',
        'fields' => array(
            array(
                'id'       => 'waulah-custom-fonts',
                'type'     => 'switch',
                'title'    => esc_html__( 'Custom Google Fonts', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'You can enable custom google fonts for your theme here.', 'waulah-extensions' ),
                'default'  => 0,
                'on'       => 'Custom Fonts',
                'off'      => 'Default Fonts',
            ),
			array(
                'id'			=> 'waulah-default-font',
                'type'			=> 'typography',
				'required' => array( 'waulah-custom-fonts', '=', '1' ),
                'title'			=> esc_html__( 'Body Font', 'waulah-extensions' ),
                'subtitle' 		=> esc_html__( 'This is default font for most of the page elements.', 'waulah-extensions' ),
                'output'      	=> array( 'body,.dropdown-menu li a,.menu-thumb .menu-thumb-title > .pub-by,.post-card.style1 .post-stats, .post-card .post-stats a, .link-url a, input, button, select, textarea, .article-subtitle, .search-query > span, .archive-title > small > span, .comments-heading .art-title, .not-found h1 small, .aside-widget .aside-article h4 a, .ft-widget .aside-article  h4 a,.logo-wrap .logo,.menu-thumb .menu-thumb-title,.featured-slider .swiper-slide .slide-inner .slide-title a, .dropcap, .mega-menu-fullwidth > .dropdown-menu > li > a, .navbar-brand' ),
                'units'       	=> 'px',
                'google'		=> true,
				'all_styles'	=> true,
				'font-size'     => false,
				'font-style'    => false,
				'line-height'   => false,
				'color'         => false,
				'text-align'    => false,
				'font-weight'	=> false
            ),
			array(
                'id'			=> 'waulah-heading-font',
                'type'			=> 'typography',
				'required' => array( 'waulah-custom-fonts', '=', '1' ),
                'title'			=> esc_html__( 'Headings Font', 'waulah-extensions' ),
                'subtitle' 		=> esc_html__( 'This font will apply on all headings from H1 to H6.', 'waulah-extensions' ),
				'desc'       => esc_html__( 'You can also apply heading font styles to any text element using .h1, .h2, .h3, .h4, .h5, .h6 heading classes.', 'waulah-extensions' ),
                'output'      	=> array( 'h1,h2,h3,h4,h5,h6,h1 a,h2 a,h3 a,h4 a,h5 a,h6 a,.h1,.h2,.h3,.h4,.h5,.h6' ),
                'units'       	=> 'px',
                'google'		=> true,
				'all_styles'	=> true,
				'font-size'     => false,
				'font-style'    => false,
				'line-height'   => false,
				'color'         => false,
				'text-align'    => false,
				'font-weight'	=> false
            )
        )
    ) );
	
	// custom css
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom CSS', 'waulah-extensions' ),
        'id'         => 'waulah-custom-css',
        'icon'  => 'el el-edit',
        'desc'       => esc_html__( 'This section allows you to enter your own custom CSS styles.', 'waulah-extensions' ),
        'fields'     => array(
            array(
                'id'       => 'waulah-css-editor',
                'type'     => 'ace_editor',
                'title'    => esc_html__( 'CSS Code', 'waulah-extensions' ),
                'subtitle' => esc_html__( 'Paste your CSS code here.', 'waulah-extensions' ),
                'mode'     => 'css',
                'theme'    => 'monokai',
            )
        )
    ) );

    /*
     * <--- END SECTIONS
     */
