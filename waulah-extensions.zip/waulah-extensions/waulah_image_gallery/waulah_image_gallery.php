<?php

if ( ! class_exists( 'waulah_Image_Gallery' ) ) {

	/**
	 * PHP5 constructor method.
	 *
	 * @since 1.0
	*/
	class waulah_Image_Gallery {

		public function __construct() {
			add_action( 'plugins_loaded', array( $this, 'constants' ));
			add_action( 'plugins_loaded', array( $this, 'includes' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'waulah_image_gallery_plugin_action_links' );
		}


		/**
		 * Constants
		 *
		 * @since 1.0
		*/
		public function constants() {

			if ( !defined( 'waulah_IMAGE_GALLERY_DIR' ) )
				define( 'waulah_IMAGE_GALLERY_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );

			if ( !defined( 'waulah_IMAGE_GALLERY_URL' ) )
			    define( 'waulah_IMAGE_GALLERY_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );

			if ( ! defined( 'waulah_IMAGE_GALLERY_VERSION' ) )
			    define( 'waulah_IMAGE_GALLERY_VERSION', '1.2' );

			if ( ! defined( 'waulah_IMAGE_GALLERY_INCLUDES' ) )
			    define( 'waulah_IMAGE_GALLERY_INCLUDES', waulah_IMAGE_GALLERY_DIR . trailingslashit( 'includes' ) );

		}

		/**
		* Loads the initial files needed by the plugin.
		*
		* @since 1.0
		*/
		public function includes() {

			require_once( waulah_IMAGE_GALLERY_INCLUDES . 'template-functions.php' );
			require_once( waulah_IMAGE_GALLERY_INCLUDES . 'scripts.php' );
			require_once( waulah_IMAGE_GALLERY_INCLUDES . 'metabox.php' );
			require_once( waulah_IMAGE_GALLERY_INCLUDES . 'admin-page.php' );

		}

	}
}

$waulah_image_gallery = new waulah_Image_Gallery();
