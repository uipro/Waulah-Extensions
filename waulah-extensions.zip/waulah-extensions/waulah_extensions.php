<?php
/*
Plugin Name:  Waulah Extensions
Plugin URI:   http://www.uipro.net/
Description:  This plugin is developed to enhance capabilities of waulah WordPress theme and to provide some advanced features.
Version:      1.0.0
Author:       Uipro
Author URI:   http://uipro.net/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  waulah-extensions
Domain Path:  /languages
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


    // Load theme options
    if ( file_exists( dirname( __FILE__ ) . '/waulah_theme_options/admin-init.php' ) ) {
        require_once dirname( __FILE__ ) . '/waulah_theme_options/admin-init.php';
    }
	
    // Load custom widgets
    if ( file_exists( dirname( __FILE__ ) . '/waulah_widgets/waulah_widgets_index.php' ) ) {
        require_once dirname( __FILE__ ) . '/waulah_widgets/waulah_widgets_index.php';
    }
	
    // Post views count
    if ( file_exists( dirname( __FILE__ ) . '/waulah_post_views_count/waulah_post_views_count.php' ) ) {
        require_once dirname( __FILE__ ) . '/waulah_post_views_count/waulah_post_views_count.php';
    }
	
    // Share this post
    if ( file_exists( dirname( __FILE__ ) . '/waulah_share/waulah_share.php' ) ) {
        require_once dirname( __FILE__ ) . '/waulah_share/waulah_share.php';
    }
	
    // Image gallery
    if ( file_exists( dirname( __FILE__ ) . '/waulah_image_gallery/waulah_image_gallery.php' ) ) {
        require_once dirname( __FILE__ ) . '/waulah_image_gallery/waulah_image_gallery.php';
    }
	
    // Load ACF files
    if ( file_exists( dirname( __FILE__ ) . '/advanced-custom-fields/acf.php' ) ) {
		define( 'ACF_LITE', true );
        require_once dirname( __FILE__ ) . '/advanced-custom-fields/acf.php';
    }	
	
	// load plugin text domain
	if( ! function_exists( 'waulah_load_plugin_textdomain' ) ){
		function waulah_load_plugin_textdomain() {
			load_plugin_textdomain( 'waulah-extensions', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
		}
	}
	add_action( 'plugins_loaded', 'waulah_load_plugin_textdomain' );


?>