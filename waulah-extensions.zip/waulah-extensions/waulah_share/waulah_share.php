<?php
if( ! function_exists( 'waulah_share_links_js' ) ){
	function waulah_share_links_js() {
		if ( is_single() ) {
			wp_enqueue_script( 'waulah_share_js', plugin_dir_url( __FILE__ ) . 'share-links.js', array('jquery'), '', true );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'waulah_share_links_js' );

if( ! function_exists( 'get_share_links' ) ){
	function get_share_links( $atts ) {	
		
		return '<ul id="share-list" class="share-this clearfix">
		<li><a href="javascript:void(0);" class="facebook" title="' . esc_attr__( 'Share on Facebook', 'waulah-extensions' ) . '"><i class="fa fa-facebook first"></i><i class="fa fa-facebook second"></i></a></li>
		<li><a href="javascript:void(0);" class="twitter" title="' . esc_attr__( 'Share on Twitter', 'waulah-extensions' ) . '"><i class="fa fa-twitter first"></i><i class="fa fa-twitter second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="linkedin" title="' . esc_attr__( 'Share on Linkedin', 'waulah-extensions' ) . '"><i class="fa fa-linkedin first"></i><i class="fa fa-linkedin second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="pinterest" title="' . esc_attr__( 'Share on Pinterest', 'waulah-extensions' ) . '"><i class="fa fa-pinterest-p first"></i><i class="fa fa-pinterest-p second"></i></a></li>
		<li><a href="javascript:void(0);" class="google" title="' . esc_attr__( 'Share on Google plus', 'waulah-extensions' ) . '"><i class="fa fa-google-plus first"></i><i class="fa fa-google-plus second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="reddit" title="' . esc_attr__( 'Share on Reddit', 'waulah-extensions' ) . '"><i class="fa fa-reddit-alien first"></i><i class="fa fa-reddit-alien second"></i></a></li>		
		<li class="hidden-xs"><a href="javascript:void(0);" class="stumbleupon" title="' . esc_attr__( 'Share on Stumbleupon', 'waulah-extensions' ) . '"><i class="fa fa-stumbleupon first"></i><i class="fa fa-stumbleupon second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="tumblr" title="' . esc_attr__( 'Share on Tumblr', 'waulah-extensions' ) . '"><i class="fa fa-tumblr first"></i><i class="fa fa-tumblr second"></i></a></li>		
		<li class="hidden-xs"><a href="javascript:void(0);" class="vk" title="' . esc_attr__( 'Share on VKontakte', 'waulah-extensions' ) . '"><i class="fa fa-vk first"></i><i class="fa fa-vk second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="odnoklassniki" title="' . esc_attr__( 'Share on Odnoklassniki', 'waulah-extensions' ) . '"><i class="fa fa-odnoklassniki first"></i><i class="fa fa-odnoklassniki second"></i></a></li>
		<li class="hidden-xs"><a href="javascript:void(0);" class="pocket" title="' . esc_attr__( 'Share on Pocket', 'waulah-extensions' ) . '"><i class="fa fa-get-pocket first"></i><i class="fa fa-get-pocket second"></i></a></li>
		<li class="visible-xs"><a href="javascript:void(0);" class="viber" title="' . esc_attr__( 'Share on Viber', 'waulah-extensions' ) . '"><i class="fa fa-volume-control-phone first"></i><i class="fa fa-volume-control-phone second"></i></a></li>
		<li class="visible-xs"><a href="javascript:void(0);" class="whatsapp" title="' . esc_attr__( 'Share on whatsapp', 'waulah-extensions' ) . '"><i class="fa fa-whatsapp first"></i><i class="fa fa-whatsapp second"></i></a></li>
		<li class="visible-xs"><a href="javascript:void(0);" class="telegram" title="' . esc_attr__( 'Share on telegram', 'waulah-extensions' ) . '"><i class="fa fa-paper-plane first"></i><i class="fa fa-paper-plane second"></i></a></li>		
		</ul>';
	}
}
add_shortcode('share_links', 'get_share_links');

?>