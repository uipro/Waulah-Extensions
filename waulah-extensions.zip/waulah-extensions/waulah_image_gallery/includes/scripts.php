<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

/**
 * Scripts
 *
 * @since 1.0
 */
function waulah_image_gallery_scripts() {

	global $post;

	// return if post object is not set
	if ( !isset( $post->ID ) )
		return;


	// JS
	wp_enqueue_script( 'magnific-popup', waulah_IMAGE_GALLERY_URL . 'includes/lib/magnific_popup/magnific_popup.js', array( 'jquery' ), waulah_IMAGE_GALLERY_VERSION, true );

	// CSS
	wp_enqueue_style( 'magnific-popup', waulah_IMAGE_GALLERY_URL . 'includes/lib/magnific_popup/magnific_popup.css', '', waulah_IMAGE_GALLERY_VERSION, 'screen' );
	// CSS
	wp_enqueue_style( 'waulah-image-gallery', waulah_IMAGE_GALLERY_URL . 'includes/css/waulah-image-gallery.css', '', waulah_IMAGE_GALLERY_VERSION, 'screen' );

}
add_action( 'wp_enqueue_scripts', 'waulah_image_gallery_scripts', 20 );




/**
 * JS
 *
 * @since 1.0
 */
function waulah_image_gallery_js() {

	global $post;

	// return if post object is not set
	if ( !isset( $post->ID ) )
		return;

ob_start(); ?>

<script>
  jQuery(document).ready(function() {						  
	jQuery(".grid, .image-gallery").magnificPopup({
		removalDelay: 300,
		disableOn: 400,
		mainClass: 'mfp-with-zoom',
		type: 'image',
		delegate: '.popup',
		gallery:{
			enabled:true
		}
	});
  });
</script>

<?php 
	$js = ob_get_clean();
	echo apply_filters( 'waulah_image_gallery_magnificpopup_js', $js );
?>

<?php }
add_action( 'wp_footer', 'waulah_image_gallery_js', 20 );


/**
 * CSS for admin
 *
 * @since 1.0
 */
function waulah_image_gallery_admin_css() { ?>

	<style>
		.attachment.details .check div {
			background-position: -60px 0;
		}

		.attachment.details .check:hover div {
			background-position: -60px 0;
		}

		.gallery_images .details.attachment {
			box-shadow: none;
		}

		.eig-metabox-sortable-placeholder {
			background: #DFDFDF;
		}

		.gallery_images .attachment.details > div {
			width: 150px;
			height: 150px;
			box-shadow: none;
		}

		.gallery_images .attachment-preview .thumbnail {
			 cursor: move;
		}

		.attachment.details div:hover .check {
			display:block;
		}

        .gallery_images:after,
        #gallery_images_container:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }

        .gallery_images > li {
            float: left;
            cursor: move;
            margin: 0 20px 20px 0;
        }

        .gallery_images li.image img {
            width: 150px;
            height: auto;
        }

    </style>

<?php }
add_action( 'admin_head', 'waulah_image_gallery_admin_css' );