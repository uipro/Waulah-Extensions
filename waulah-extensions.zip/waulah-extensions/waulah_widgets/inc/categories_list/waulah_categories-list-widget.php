<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('categories_title'); ?>" type="text" value="<?php echo $categories_title; ?>">
</p>
