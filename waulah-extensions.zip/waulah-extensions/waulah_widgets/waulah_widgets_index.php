<?php

/* ------------------------------------------------
   *  Flickr widget
--------------------------------------------------- */
class waulah_Flickr_Widget extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Flickr Widget' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$flickr_title = apply_filters( 'widget_title', $instance['flickr_title'] );
		$flickr_feed = $instance['flickr_feed'];
		$flickr_feed_count = $instance['flickr_feed_count'];
		
		require('inc/flickr/flickr-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['flickr_title'] = strip_tags($new_instance['flickr_title']);
		$instance['flickr_feed'] = strip_tags($new_instance['flickr_feed']);
		$instance['flickr_feed_count'] = strip_tags($new_instance['flickr_feed_count']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['flickr_title'] ) ){
			$flickr_title = esc_attr( $instance['flickr_title'] );
		} else {
			$flickr_title = NULL;
		}
		
		if ( isset( $instance['flickr_feed'] ) ){
			$flickr_feed = esc_attr( $instance['flickr_feed'] );
		} else {
			$flickr_feed = NULL;
		}
		
		if ( isset( $instance['flickr_feed_count'] ) ){
			$flickr_feed_count = esc_attr( $instance['flickr_feed_count'] );
		} else {
			$flickr_feed_count = NULL;
		}
		
		require('inc/flickr/waulah_flickr-widget.php');
	}
}



/* ------------------------------------------------
   *  Featured Posts
--------------------------------------------------- */
class waulah_Featured_Posts extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Featured Posts' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$featured_title = apply_filters( 'featured_title', $instance['featured_title'] );
		$featured_posts_count = $instance['featured_posts_count'];
		$filter_posts_by = $instance['filter_posts_by'];
		
		require('inc/featured_posts/featured-posts-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['featured_title'] = strip_tags($new_instance['featured_title']);
		$instance['featured_posts_count'] = strip_tags($new_instance['featured_posts_count']);
		$instance['filter_posts_by'] = strip_tags($new_instance['filter_posts_by']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['featured_title'] ) ){
			$featured_title = esc_attr( $instance['featured_title'] );
		} else {
			$featured_title = NULL;
		}
		
		if ( isset( $instance['featured_posts_count'] ) ){
			$featured_posts_count = esc_attr( $instance['featured_posts_count'] );
		} else {
			$featured_posts_count = NULL;
		}
		
		if ( isset( $instance['filter_posts_by'] ) ){
			$filter_posts_by = esc_attr( $instance['filter_posts_by'] );
		} else {
			$filter_posts_by = NULL;
		}
		
		require('inc/featured_posts/waulah_featured-posts-widget.php');
	}
}



/* ------------------------------------------------
   *  Categories List
--------------------------------------------------- */
class waulah_Categories_List extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Categories List' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$categories_title = apply_filters( 'categories_title', $instance['categories_title'] );		
		require('inc/categories_list/categories-list-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['categories_title'] = strip_tags($new_instance['categories_title']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['categories_title'] ) ){
			$categories_title = esc_attr( $instance['categories_title'] );
		} else {
			$categories_title = NULL;
		}
		
		require('inc/categories_list/waulah_categories-list-widget.php');
	}
}



/* ------------------------------------------------
   *  Mailchimp Subscription Form widget
--------------------------------------------------- */
class waulah_Mailchimp_Widget extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Mailchimp Form Widget' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$mailchimp_title = apply_filters( 'widget_title', $instance['mailchimp_title'] );
		$mailchimp_sub_title = $instance['mailchimp_sub_title'];
		$mailchimp_form_url = $instance['mailchimp_form_url'];
		
		require('inc/mailchimp/mailchimp-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['mailchimp_title'] = strip_tags($new_instance['mailchimp_title']);
		$instance['mailchimp_sub_title'] = strip_tags($new_instance['mailchimp_sub_title']);
		$instance['mailchimp_form_url'] = strip_tags($new_instance['mailchimp_form_url']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['mailchimp_title'] ) ){
			$mailchimp_title = esc_attr( $instance['mailchimp_title'] );
		} else {
			$mailchimp_title = NULL;
		}
		
		if ( isset( $instance['mailchimp_sub_title'] ) ){
			$mailchimp_sub_title = esc_attr( $instance['mailchimp_sub_title'] );
		} else {
			$mailchimp_sub_title = NULL;
		}
		
		if ( isset( $instance['mailchimp_form_url'] ) ){
			$mailchimp_form_url = esc_attr( $instance['mailchimp_form_url'] );
		} else {
			$mailchimp_form_url = NULL;
		}
		
		require('inc/mailchimp/waulah_mailchimp-widget.php');
	}
}



/* ------------------------------------------------
   *  About Me
--------------------------------------------------- */
class waulah_About_Me extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah About Me' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$about_title = apply_filters( 'about_title', $instance['about_title'] );
		$about_img_url = $instance['about_img_url'];
		$about_intro = $instance['about_intro'];
		$about_signature = $instance['about_signature'];
		$about_profile = $instance['about_profile'];
		
		require('inc/about_me/about-me-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['about_title'] = strip_tags($new_instance['about_title']);
		$instance['about_img_url'] = strip_tags($new_instance['about_img_url']);
		$instance['about_intro'] = strip_tags($new_instance['about_intro']);
		$instance['about_signature'] = strip_tags($new_instance['about_signature']);
		$instance['about_profile'] = strip_tags($new_instance['about_profile']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['about_title'] ) ){
			$about_title = esc_attr( $instance['about_title'] );
		} else {
			$about_title = NULL;
		}
		
		if ( isset( $instance['about_img_url'] ) ){
			$about_img_url = esc_attr( $instance['about_img_url'] );
		} else {
			$about_img_url = NULL;
		}
		
		if ( isset( $instance['about_intro'] ) ){
			$about_intro = esc_attr( $instance['about_intro'] );
		} else {
			$about_intro = NULL;
		}
		
		if ( isset( $instance['about_signature'] ) ){
			$about_signature = esc_attr( $instance['about_signature'] );
		} else {
			$about_signature = NULL;
		}
		
		if ( isset( $instance['about_profile'] ) ){
			$about_profile = esc_attr( $instance['about_profile'] );
		} else {
			$about_profile = NULL;
		}
		
		require('inc/about_me/waulah_about-me-widget.php');
	}
}



/* ------------------------------------------------
   *  Follow Me
--------------------------------------------------- */
class waulah_Follow_Me extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Follow Me' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$follow_title = apply_filters( 'follow_title', $instance['follow_title'] );
		
		require('inc/follow_me/follow-me-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['follow_title'] = strip_tags($new_instance['follow_title']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['follow_title'] ) ){
			$follow_title = esc_attr( $instance['follow_title'] );
		} else {
			$follow_title = NULL;
		}
		
		require('inc/follow_me/waulah_follow-me-widget.php');
	}
}



/* ------------------------------------------------
   *  Sidebar Ad ( advertisement )
--------------------------------------------------- */
class waulah_Sidebar_Ad extends WP_Widget {
	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'waulah Sidebar Ad' );
	}
	function widget( $args, $instance ) {
		// Widget output
		extract( $args );
		$ad_img_url = $instance['ad_img_url'];
		$ad_link = $instance['ad_link'];
		
		require('inc/sidebar_ad/sidebar-ad-front-end.php');
		
	}
	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance = $old_instance;
		$instance['ad_img_url'] = strip_tags($new_instance['ad_img_url']);
		$instance['ad_link'] = strip_tags($new_instance['ad_link']);
		return $instance;
	}
	function form( $instance ) {
		// Output admin widget options form
		
		if ( isset( $instance['ad_img_url'] ) ){
			$ad_img_url = esc_attr( $instance['ad_img_url'] );
		} else {
			$ad_img_url = NULL;
		}
		
		if ( isset( $instance['ad_link'] ) ){
			$ad_link = esc_attr( $instance['ad_link'] );
		} else {
			$ad_link = NULL;
		}
		
		require('inc/sidebar_ad/waulah_sidebar-ad-widget.php');
	}
}




// register widgets
function waulah_register_widgets() {
	register_widget( 'waulah_Flickr_Widget' );
	register_widget( 'waulah_Featured_Posts' );
	register_widget( 'waulah_Categories_List' );
	register_widget( 'waulah_Mailchimp_Widget' );
	register_widget( 'waulah_About_Me' );
	register_widget( 'waulah_Follow_Me' );
	register_widget( 'waulah_Sidebar_Ad' );
}
add_action( 'widgets_init', 'waulah_register_widgets' );


// enqueue flickr jQuery script
function waulah_widgets_js() {
	wp_enqueue_script( 'flickr_js', plugins_url( '/inc/flickr/js/flickr.js', __FILE__ ), array('jquery', 'bootstrap'), '', true );
	wp_enqueue_script( 'mailchimp_js', plugins_url( '/inc/mailchimp/js/ajaxchimp.js', __FILE__ ), array('jquery', 'bootstrap'), '', true );
}
add_action( 'wp_enqueue_scripts', 'waulah_widgets_js' );


?>