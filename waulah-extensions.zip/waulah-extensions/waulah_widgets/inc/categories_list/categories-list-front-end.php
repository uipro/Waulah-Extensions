<?php
	
	echo $before_widget;
	if ( !empty( $categories_title ) ) {
		echo $before_title . $categories_title . $after_title;
	}
?>

<?php $categories = get_terms( 'category' ); ?>
<ul class="waulah-cat-widget clearfix">
<?php
foreach ( $categories as $category ) {
	$category_color = get_field('category_accent_color', 'category_'. $category->term_id );
	echo '<li><a href="' . get_category_link( $category->term_id ) . '" title="' . $category->name . '">' . $category->name . ' <span class="label cat-post-count" style="background-color:' . $category_color . ';">' . $category->count . '</span></a></li>';
}
?>
</ul>

<?php echo $after_widget; ?>


