<?php	
	echo $before_widget;
	if ( !empty( $follow_title ) ) {
		echo $before_title . $follow_title . $after_title;
	}
	get_template_part ( '/inc/waulah', 'social' );
	echo $after_widget; ?>


